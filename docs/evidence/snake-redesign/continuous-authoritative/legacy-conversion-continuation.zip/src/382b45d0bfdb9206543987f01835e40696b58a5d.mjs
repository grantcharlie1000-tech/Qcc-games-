import {chromium} from '/workspace/qcc-snake/node_modules/playwright/index.mjs';
import {mkdir,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const folder='/workspace/qcc-snake/docs/evidence/snake-redesign/continuous-authoritative';
await mkdir(folder,{recursive:true});
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const results={recordedAt:new Date().toISOString(),browser:browser.version(),physicalHardware:false,sourceCheckpoint:'511ed3bc51e47dd4b1f53b32c072b0ae4c95174d',viewports:[],errors:[],externalRequests:[]};
async function setup(viewport,options={}){
 const context=await browser.newContext({viewport,deviceScaleFactor:1,...options});
 await context.addInitScript(()=>sessionStorage.setItem('pocket-arcade:study:v1:topic','close-reading'));
 const page=await context.newPage();page.on('pageerror',e=>results.errors.push(e.message));
 page.on('request',r=>{if(r.url().startsWith('http')&&new URL(r.url()).origin!=='http://127.0.0.1:4181')results.externalRequests.push(r.url());});
 await page.clock.install({time:new Date('2026-10-20T10:00:00Z')});await page.clock.pauseAt(new Date('2026-10-20T10:00:01Z'));
 return {context,page};
}
const saved=page=>page.evaluate(()=>JSON.parse(localStorage.getItem('pocket-arcade:v1:save:snake')).data);
const png=page=>page.locator('canvas').evaluate(c=>c.toDataURL().split(',')[1]);
const image=async(page,name)=>writeFile(folder+'/'+name,Buffer.from(await png(page),'base64'));
async function pause(page){await page.getByRole('button',{name:'Pause game',exact:true}).click();return saved(page);}
try{
 for(const viewport of[{width:1440,height:1200},{width:1366,height:768},{width:844,height:390},{width:390,height:844},{width:320,height:568}]){
  const {context,page}=await setup(viewport);
  if(viewport.width===1440)await context.tracing.start({screenshots:true,snapshots:true,sources:true});
  await page.goto('http://127.0.0.1:4181/#/game/snake');await page.getByRole('button',{name:'Start slithering',exact:true}).click();
  if(viewport.width===1440){
   await page.clock.runFor(240);const frames=[];
   for(const time of[240,272,304]){
    if(time>240)await page.clock.runFor(32);
    const crop=await page.locator('canvas').evaluate(c=>{const out=document.createElement('canvas'),scale=c.width/480;out.width=Math.round(140*scale);out.height=Math.round(65*scale);out.getContext('2d').drawImage(c,110*scale,165*scale,140*scale,65*scale,0,0,out.width,out.height);return out.toDataURL().split(',')[1];});
    await writeFile(folder+'/motion-'+time+'.png',Buffer.from(crop,'base64'));
    frames.push({activeMilliseconds:time,aria:await page.locator('canvas').getAttribute('aria-label'),crop});
   }
   assert.notEqual(frames[0].crop,frames[1].crop);assert.notEqual(frames[1].crop,frames[2].crop);
   results.motionFrames=frames.map(({crop,...rest})=>rest);await page.clock.runFor(256);
  }else await page.clock.runFor(560);
  assert.equal(await page.locator('#game-score strong').textContent(),'10');
  await page.keyboard.press('ArrowUp');await page.clock.runFor(170);await page.keyboard.press('ArrowLeft');await page.clock.runFor(170);
  await page.screenshot({path:folder+'/after-'+viewport.width+'x'+viewport.height+'.png',fullPage:true});
  const measure=await page.evaluate(()=>{const c=document.querySelector('canvas'),g=document.querySelector('.snake-garden'),p=document.querySelector('.snake-pad'),r=c.getBoundingClientRect(),b=g.getBoundingClientRect(),pad=p.getBoundingClientRect();return {width:innerWidth,height:innerHeight,garden:b.width,playable:r.width,canvasHeight:r.height,backing:c.width,dpr:devicePixelRatio,overflowX:document.documentElement.scrollWidth>innerWidth,overflowY:document.documentElement.scrollHeight>innerHeight,padRight:pad.right,padBottom:pad.bottom,renderedAria:c.getAttribute('aria-label')};});
  assert.equal(measure.overflowX,false);assert.equal(measure.overflowY,false);assert.equal(measure.backing,Math.round(measure.playable*measure.dpr));
  const state=await pause(page);assert.equal(state.score,10);assert.equal(state.segments,4);assert.equal(state.direction,'left');
  results.viewports.push({...measure,canonicalSnapshotAtPause:state});
  if(viewport.width===1440){
   const frozen=await png(page);await page.clock.runFor(5000);assert.equal(await png(page),frozen);await page.reload();assert.equal(await png(page),frozen);await page.getByRole('button',{name:'Pause game',exact:true}).click();assert.deepEqual(await saved(page),state);
   results.fractionalReload={pixelsIdentical:true,stateIdentical:true,pausedForMilliseconds:5000};
   await page.getByRole('button',{name:'Resume game',exact:true}).click();await page.keyboard.press('ArrowUp');await page.clock.runFor(1000);
   assert.equal(await page.getByRole('button',{name:'Play again',exact:true}).isVisible(),true);const collision=await saved(page);assert.equal(collision.phase,'lost');assert.equal(collision.direction,'up');assert.ok(Math.abs(collision.body[0].y+.1)<1e-8);
   await page.screenshot({path:folder+'/wall-up-feedback.png',fullPage:true});await image(page,'wall-up-canvas.png');results.wallCollision=collision;
   await context.tracing.stop({path:folder+'/keyboard-motion-collision.zip'});
  }
  await context.close();
 }
 {
  const {context,page}=await setup({width:390,height:844},{hasTouch:true,isMobile:true,deviceScaleFactor:2,reducedMotion:'reduce'});
  await context.tracing.start({screenshots:true,snapshots:true,sources:true});await page.goto('http://127.0.0.1:4181/#/game/snake');await page.getByRole('button',{name:'Start slithering',exact:true}).tap();await page.clock.runFor(240);
  const cdp=await context.newCDPSession(page),box=await page.locator('canvas').boundingBox(),x=box.x+box.width/2,y=box.y+box.height/2;
  async function swipe(cancel){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x,y:y-65}]});await cdp.send('Input.dispatchTouchEvent',{type:cancel?'touchCancel':'touchEnd',touchPoints:[]});}
  await swipe(true);const cancelled=await pause(page);assert.deepEqual(cancelled.queue,[]);assert.equal(cancelled.direction,'right');await page.getByRole('button',{name:'Resume game',exact:true}).tap();await swipe(false);await page.clock.runFor(100);await page.getByRole('button',{name:'Turn left',exact:true}).tap();await page.clock.runFor(180);
  await page.screenshot({path:folder+'/native-touch-playing.png',fullPage:true});const touch=await pause(page);assert.equal(touch.direction,'left');assert.ok(touch.body[0].x<7&&touch.body[0].y<6);results.nativeTouch={cancelled,validSwipeAndPad:touch,reducedMotion:await page.locator('.snake-game').getAttribute('data-reduced-motion')};await context.tracing.stop({path:folder+'/touch-cancel-and-steer.zip'});await context.close();
 }
 {
  const {context,page}=await setup({width:1366,height:768});await context.tracing.start({screenshots:true,snapshots:true,sources:true});await page.goto('http://127.0.0.1:4181/');
  const old={version:1,seed:7,body:[{x:7,y:6},{x:6,y:6},{x:5,y:6},{x:4,y:6}],food:{x:9,y:9},direction:'right',queue:['up'],phase:'running',score:10,elapsed:93,ticks:4,presentation:{foodAge:80,eatAge:30,eaten:{x:7,y:6}}};
  await page.evaluate(data=>localStorage.setItem('pocket-arcade:v1:save:snake',JSON.stringify({version:1,data})),old);await page.goto('http://127.0.0.1:4181/#/game/snake');await page.getByRole('button',{name:'Continue saved run',exact:true}).waitFor();await page.clock.runFor(10000);await page.screenshot({path:folder+'/legacy-safe-continuation.png',fullPage:true});const held=await pause(page);
  for(const key of['body','seed','food','score','phase','queue','direction','ticks'])assert.deepEqual(held[key],old[key],key);assert.deepEqual(held.migration,{elapsed:93,held:true});assert.equal(held.elapsed,0);
  await page.reload();await page.getByRole('button',{name:'Continue saved run',exact:true}).click();await page.clock.runFor(80);const continued=await pause(page);assert.deepEqual(continued.body[0],{x:7,y:5.5});assert.equal(continued.direction,'up');assert.deepEqual(continued.queue,[]);assert.equal(continued.score,10);const pixels=await png(page);await page.reload();assert.equal(await png(page),pixels);await page.getByRole('button',{name:'Pause game',exact:true}).click();assert.deepEqual(await saved(page),continued);
  results.legacyConversion={old,held,continued,v2ReloadStateAndPixelsIdentical:true};await context.tracing.stop({path:folder+'/legacy-conversion-continuation.zip'});await context.close();
 }
 assert.deepEqual(results.errors,[]);assert.deepEqual(results.externalRequests,[]);await writeFile(folder+'/browser-evidence.json',JSON.stringify(results,null,2));console.log('PASS five responsive viewports, smooth pixel frames, exact fractional reload, native touch cancellation/steering, wall contact and v1→v2 conversion/reload');
}finally{await browser.close();}
