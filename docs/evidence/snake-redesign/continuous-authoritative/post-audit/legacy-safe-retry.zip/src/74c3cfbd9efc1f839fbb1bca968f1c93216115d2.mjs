import {chromium} from '/workspace/qcc-snake/node_modules/playwright/index.mjs';
import {writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const folder='/workspace/qcc-snake/docs/evidence/snake-redesign/continuous-authoritative/post-audit';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const results={source:'03d4a1c4c800bf803999d4859431e98d1c2982ce',recordedAt:new Date().toISOString(),cases:[],pageErrors:[]};
const legacy={version:1,seed:7,body:[{x:5,y:6},{x:4,y:6},{x:3,y:6}],food:{x:9,y:9},direction:'up',queue:[],phase:'running',score:0,elapsed:93,ticks:1};
const coordinates=(actual,expected)=>{for(const key of ['x','y'])assert.ok(Math.abs(actual[key]-expected[key])<=8*Number.EPSILON*Math.max(1,Math.abs(expected[key])),key+' differs from analytic expectation beyond floating-point roundoff');};
const saved=page=>page.evaluate(()=>JSON.parse(localStorage.getItem('pocket-arcade:v1:save:snake')).data);
async function setup(data){
 const context=await browser.newContext({viewport:{width:1366,height:768}});await context.addInitScript(()=>sessionStorage.setItem('pocket-arcade:study:v1:topic','close-reading'));
 const page=await context.newPage();page.on('pageerror',e=>results.pageErrors.push(e.message));await page.clock.install({time:new Date('2026-10-20T10:00:00Z')});await page.clock.pauseAt(new Date('2026-10-20T10:00:01Z'));
 await page.goto('http://127.0.0.1:4181/');await page.evaluate(data=>localStorage.setItem('pocket-arcade:v1:save:snake',JSON.stringify({version:1,data})),data);await page.goto('http://127.0.0.1:4181/#/game/snake');
 return {context,page};
}
async function pause(page){await page.getByRole('button',{name:'Pause game',exact:true}).click();return saved(page);}
try{
 for(const [name,data] of[['reverse heading',{...legacy,direction:'left'}],['unsafe saved first turn',{...legacy,queue:['left']}]] ){
  const {context,page}=await setup(data);assert.equal(await page.getByRole('button',{name:'Start slithering',exact:true}).isVisible(),true);await page.keyboard.press('ArrowRight');await page.clock.runFor(80);const state=await pause(page);assert.equal(state.migration,null);assert.equal(state.direction,'right');coordinates(state.body[0],{x:5.5,y:6});assert.equal(state.segments,3);results.cases.push({name,recoveredFresh:true,state});await context.close();
 }
 {
  const {context,page}=await setup(legacy);await context.tracing.start({screenshots:true,snapshots:true,sources:true});await page.getByRole('button',{name:'Continue saved run',exact:true}).waitFor();const before=await pause(page);await page.getByRole('button',{name:'Resume game',exact:true}).click();await page.keyboard.press('ArrowLeft');assert.equal(await page.getByRole('button',{name:'Continue saved run',exact:true}).isVisible(),true);const rejected=await pause(page);assert.deepEqual(rejected,before);await page.getByRole('button',{name:'Resume game',exact:true}).click();await page.keyboard.press('ArrowUp');await page.clock.runFor(80);const safe=await pause(page);coordinates(safe.body[0],{x:5,y:5.5});assert.equal(safe.direction,'up');assert.equal(safe.migration.held,false);await page.reload();await page.getByRole('button',{name:'Pause game',exact:true}).click();assert.deepEqual(await saved(page),safe);results.cases.push({name:'unsafe continuation immutable; safe retry and v2 reload',before,rejected,safe});await context.tracing.stop({path:folder+'/legacy-safe-retry.zip'});await context.close();
 }
 {
  const data={...legacy,body:[{x:7,y:6},{x:6,y:6},{x:5,y:6},{x:4,y:6}],direction:'right',queue:['up'],score:10,ticks:4};const {context,page}=await setup(data);await page.clock.runFor(6000);const held=await pause(page);for(const key of['body','seed','food','score','phase','queue','direction','ticks'])assert.deepEqual(held[key],data[key]);assert.deepEqual(held.migration,{elapsed:93,held:true});await page.reload();await page.getByRole('button',{name:'Continue saved run',exact:true}).click();await page.clock.runFor(80);const safe=await pause(page);coordinates(safe.body[0],{x:7,y:5.5});assert.equal(safe.score,10);assert.deepEqual(safe.queue,[]);await page.reload();await page.getByRole('button',{name:'Pause game',exact:true}).click();assert.deepEqual(await saved(page),safe);results.cases.push({name:'valid legacy progress, queue priority and v2 reload',held,safe});await context.close();
 }
 {
  const data={...legacy,body:[{x:5,y:0},{x:4,y:0},{x:3,y:0}],phase:'lost',elapsed:0};const {context,page}=await setup(data);await page.getByRole('button',{name:'Play again',exact:true}).waitFor();const state=await pause(page);assert.equal(state.phase,'lost');assert.equal(state.direction,'up');assert.deepEqual(state.body,data.body);await page.reload();await page.getByRole('button',{name:'Pause game',exact:true}).click();assert.deepEqual(await saved(page),state);results.cases.push({name:'legitimate perpendicular fatal legacy direction preserved',state});await context.close();
 }
 assert.deepEqual(results.pageErrors,[]);await writeFile(folder+'/legacy-ui.json',JSON.stringify(results,null,2));console.log('PASS five actual browser legacy validation/continuation/reload scenarios; real keyboard input, unchanged state after unsafe input, safe retry and preserved fatal direction');
}finally{await browser.close();}
